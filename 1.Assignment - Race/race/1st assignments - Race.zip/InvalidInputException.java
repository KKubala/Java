package race;

class InvalidInputException extends Exception {

    public InvalidInputException() {
    }
    
}
